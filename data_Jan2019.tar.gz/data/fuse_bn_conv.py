import torch
import torchvision
import mxnet as mx
from ast import literal_eval
import pandas as pd
import numpy as np
import os

home_folder='/home/prdcv/PycharmProjects/gvh205/Pruning/'
model='prun_conv1_5_12_13_6740'
params_file = os.path.join('mxnet_model_2',model+'.params')
saved_folder=os.path.join('mxnet_model_2',model)
csv_file=os.path.join('mxnet_model_2', model+'.csv')

if not os.path.exists(saved_folder):
    os.makedirs(saved_folder)
weight_folder=saved_folder
bias_folder=saved_folder
mobilenetSSD_layer=47
mobilenetSSD_mbox_layer=12
caffe_mbox_name=['11','13','14_2','15_2','16_2','17_2']

class Model:
    #model_file: .csv file that contain detail information abt model, e.g mobilenet_SSD_300
    def __init__(self, model_file, weight_folder, bias_folder='', writefile=False):
        self.writefile=writefile
        self.layer_names=[]
        self.is_depthwise=[]
        self.input_shapes=[]
        self.weight_shapes = []
        self.bias_shapes = []
        self.output_shapes = []
        self.kernel = []
        self.stride = []
        self.pad = []
        self.relu=[]
        self.weight_scales = []
        self.data_scales = []
        self.data_scales_prev = []
        self.no_bias=False

        self.input_data = []
        self.output_data = []
        self.weights = []
        self.biases = []

        data = pd.read_csv(model_file)
        self.total_layer = mobilenetSSD_layer
        self.total_column = data.shape[1]

        self.append_value(data,'layer_name',self.layer_names)
        self.append_value(data,'is_dw',self.is_depthwise)
        self.append_value(data,'input_shape',self.input_shapes, tuple=True)
        self.append_value(data,'weight_shape',self.weight_shapes,tuple=True)
        self.append_value(data,'bias_shape',self.bias_shapes,tuple=True)
        self.append_value(data,'output_shape',self.output_shapes,tuple=True)
        self.append_value(data,'kernel',self.kernel,tuple=True)
        self.append_value(data,'stride',self.stride,tuple=True)
        self.append_value(data,'pad',self.pad,tuple=True)
        self.append_value(data,'relu',self.relu)

        print('Mobilenet_ssd_300.py. Finish initialize parameters.')

    def append_value(self, data, feature, array, boole=False, tuple=False, multiple=False):
        if(multiple==False):
            column = data[feature]
            for i in range(self.total_layer):
                if(tuple==True):
                    array.append(literal_eval(column.iloc[i]))
                else:
                    array.append(column.iloc[i])
        else:
            x=data.columns.get_loc(feature)
            for i in range(self.total_layer):
                if(self.layer_names[i]=='conv12' or self.layer_names[i]=='conv13/dw' or self.layer_names[i]=='conv13'):
                    values=[]
                    for n in range (self.bias_shapes[i][0]):
                        values.append(float(data.iat[i+24,n]))
                    array.append(values)
                else:
                    values = []
                    for n in range(self.bias_shapes[i][0]):
                        values.append(data.iat[i, x + n])
                    array.append(values)

def fuse_conv_and_bn(conv, bn):
    fusedconv = torch.nn.Conv2d(
        conv.in_channels,
        conv.out_channels,
        kernel_size=conv.kernel_size,
        stride=conv.stride,
        padding=conv.padding,
        bias=True
    )
    #
    # prepare filters
    w_conv = conv.weight.clone().view(conv.out_channels, -1)
    w_bn = torch.diag(bn.weight.div(torch.sqrt(bn.eps+bn.running_var)))
    fusedconv.weight.copy_( torch.mm(w_bn, w_conv).view(fusedconv.weight.size()) )
    #
    # prepare spatial bias
    if conv.bias is not None:
        b_conv = conv.bias
    else:
        b_conv = torch.zeros( conv.weight.size(0) )
    b_bn = bn.bias - bn.weight.mul(bn.running_mean).div(torch.sqrt(bn.running_var + bn.eps))
    fusedconv.bias.copy_( b_conv + b_bn )
    #
    # we're done
    return fusedconv


torch.set_grad_enabled(False)
mxnet_params = mx.ndarray.load(params_file)

params=Model(csv_file, weight_folder,bias_folder)



for i in range (mobilenetSSD_layer-mobilenetSSD_mbox_layer):
    x = torch.randn(params.input_shapes[i])

    conv_torch = torch.nn.Conv2d(params.weight_shapes[i][1],
                                 params.weight_shapes[i][0],
                                 kernel_size=params.kernel[i],
                                 stride=params.stride[i],
                                 padding=params.pad[i],
                                 bias=False)
    if(i<27): #base network
        conv_torch.weight.copy_(torch.tensor(mxnet_params['features.mobilenet0_conv'+str(i)+'_weight'].asnumpy()))
        conv_torch.training = False

        bn_torch = torch.nn.BatchNorm2d(params.weight_shapes[i][0])
        bn_torch.weight.copy_(torch.tensor(mxnet_params['features.mobilenet0_batchnorm'+str(i)+'_gamma'].asnumpy()))
        bn_torch.bias.copy_(torch.tensor(mxnet_params['features.mobilenet0_batchnorm'+str(i)+'_beta'].asnumpy()))
        bn_torch.running_mean = torch.tensor(mxnet_params['features.mobilenet0_batchnorm'+str(i)+'_running_mean'].asnumpy())
        bn_torch.running_var = torch.tensor(mxnet_params['features.mobilenet0_batchnorm'+str(i)+'_running_var'].asnumpy())
        bn_torch.training = False

        fusedconv = fuse_conv_and_bn(conv_torch, bn_torch)

        name_weight=''
        name_bias=''
        if(i%2==1): #dw_convolution
            name_weight = 'conv'+str((i+1)/2)+'_dw_weight'
            name_bias = 'conv'+str((i+1)/2)+'_dw_bias'
        else:
            name_weight = 'conv' + str(i / 2) + '_weight'
            name_bias = 'conv' + str(i / 2) + '_bias'
        save_weight=fusedconv.weight.detach().numpy()
        save_weight.tofile(os.path.join(weight_folder,name_weight+'.bin'))
        save_bias=fusedconv.bias.detach().numpy()
        save_bias.tofile(os.path.join(bias_folder,name_bias+'.bin'))

    else: #expand convolution
        if (i % 2 == 1):  # dw_convolution
            gluon_name_weight = 'features.expand_conv' + str((i + 1) / 2) + '_1_weight'
            gluon_name_bn = 'features.expand_bn' + str((i + 1) / 2) + '_1'
            name_weight = 'conv' + str((i + 1) / 2) + '_1_weight'
            name_bias = 'conv' + str((i + 1) / 2) + '_1_bias'
        else:
            gluon_name_weight = 'features.expand_conv' + str(i / 2) + '_2_weight'
            gluon_name_bn = 'features.expand_bn' + str(i / 2) + '_2'
            name_weight = 'conv' + str(i / 2) + '_2_weight'
            name_bias = 'conv' + str(i / 2) + '_2_bias'

        conv_torch.weight.copy_(torch.tensor(mxnet_params[gluon_name_weight].asnumpy()))
        conv_torch.training = False

        bn_torch = torch.nn.BatchNorm2d(params.weight_shapes[i][0])
        bn_torch.weight.copy_(torch.tensor(mxnet_params[gluon_name_bn + '_gamma'].asnumpy()))
        bn_torch.bias.copy_(torch.tensor(mxnet_params[gluon_name_bn + '_beta'].asnumpy()))
        bn_torch.running_mean = torch.tensor(mxnet_params[gluon_name_bn + '_moving_mean'].asnumpy())
        bn_torch.running_var = torch.tensor(mxnet_params[gluon_name_bn + '_moving_var'].asnumpy())
        bn_torch.training = False

        fusedconv = fuse_conv_and_bn(conv_torch, bn_torch)

        save_weight = fusedconv.weight.detach().numpy()
        save_weight.tofile(os.path.join(weight_folder, name_weight + '.bin'))
        save_bias = fusedconv.bias.detach().numpy()
        save_bias.tofile(os.path.join(bias_folder, name_bias + '.bin'))

for i in range(mobilenetSSD_layer-mobilenetSSD_mbox_layer,mobilenetSSD_layer): #mbox convolution, no need to fuse bn and convolution
    if (i % 2 == 1):  # mbox_loc
        gluon_name_weight = 'box_predictors.' + str((i - 35) / 2) + '.predictor.weight'
        gluon_name_bias = 'box_predictors.' + str((i - 35) / 2) + '.predictor.bias'
        name_weight = 'conv' + caffe_mbox_name[(i - 35) / 2] + '_mbox_loc_weight'
        name_bias = 'conv' + caffe_mbox_name[(i - 35) / 2] + '_mbox_loc_bias'
    else:  # mbox_conf
        gluon_name_weight = 'class_predictors.' + str((i - 36) / 2) + '.predictor.weight'
        gluon_name_bias = 'class_predictors.' + str((i - 36) / 2) + '.predictor.bias'
        name_weight = 'conv' + caffe_mbox_name[(i - 36) / 2] + '_mbox_conf_weight'
        name_bias = 'conv' + caffe_mbox_name[(i - 36) / 2] + '_mbox_conf_bias'

    save_weight = mxnet_params[gluon_name_weight].asnumpy()
    save_weight.tofile(os.path.join(weight_folder, name_weight + '.bin'))
    save_bias = mxnet_params[gluon_name_bias].asnumpy()
    save_bias.tofile(os.path.join(bias_folder, name_bias + '.bin'))

print('Finish mapping data from gluon-cv to FPGA!')

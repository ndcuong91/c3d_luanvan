import mxnet as mx
import cv2
import time
import mobilenet_ssd_300_old as mobilenetSSD
import os
import numpy as np

ctx = mx.cpu()
shape=300
num_anchor=1917
class_names = ["aeroplane", "bicycle", "bird", "boat", "bottle", "bus", "car", "cat", "chair",
               "cow", "diningtable", "dog", "horse", "motorbike", "person", "pottedplant",
               "sheep", "sofa", "train", "tvmonitor"]

#modified params
write_file=False #for test
threshold=0.5 #0.01 for mAP
image_file='/home/prdcv/PycharmProjects/gvh205/others/dog.jpg'
#image_file='/home/prdcv/PycharmProjects/gvh205/VOC dataset/VOC2007_test/JPEGImages/000002.jpg'

model='original_7161'
model_folder='mxnet_model_2'
saved_folder=os.path.join(model_folder,model)
csv_file=os.path.join(model_folder, model+'.csv')
model_file=csv_file
weight_folder=saved_folder
bias_folder=saved_folder

# model_file='mobilenet_ssd_300_quantize_channel.csv'
# weight_folder='fp32_origin/'
# bias_folder='fp32_origin/'
#for calculate mAP
mAP_cal=False
input_folder = '/home/prdcv/PycharmProjects/gvh205/VOC dataset/VOC2007_test/JPEGImages'
#output_folder='/home/prdcv/PycharmProjects/gvh205/Pruning/mxnet_model_2/predict_prun_conv12_7105/'
output_folder=os.path.join(model_folder,'predict_'+model)


def load_input(image_file, bin=False):
    if(bin==True):
        #x= np.fromfile(image_file, dtype='float32').reshape(1,3,300,300)
        origimg = cv2.imread(image_file)
        img = cv2.resize(origimg, (300, 300))
        img = img /255
        img = np.array(img) - np.array([0.485, 0.456, 0.406])
        img = np.array(img) / np.array([0.229, 0.224, 0.225])

        img = img.astype(np.float32)
        img = img.transpose((2, 0, 1))
        x = img[np.newaxis, :]
        kk=1
    else:
        origimg = cv2.imread(image_file)
        img = cv2.resize(origimg, (300, 300))
        img = np.array(img) - np.array([127.5, 127.5, 127.5])
        img = img * 0.007843
        # img = np.array(img) - np.array([123.675, 116.28, 103.53])
        # img = np.array(img) / np.array([58.395, 57.12, 57.375])
        #
        # kk=np.fromfile('/home/prdcv/PycharmProjects/gvh205/Pruning/test/2.bin', dtype='float32').reshape(1,3,300,300)
        img = img.astype(np.float32)
        img = img.transpose((2, 0, 1))
        x = img[np.newaxis, :]


    return x

def display(img, out, thresh=threshold):
    import random
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    mpl.rcParams['figure.figsize'] = (10,10)
    pens = dict()
    plt.clf()
    plt.imshow(img)
    count=0
    for det in out:
        cid = int(det[0])
        if cid < 0:
            continue
        score = det[1]
        if score < thresh:
            continue
        count += 1
        if cid not in pens:
            pens[cid] = (random.random(), random.random(), random.random())
        scales = [img.shape[1], img.shape[0]] * 2
        xmin, ymin, xmax, ymax = [int(p * s) for p, s in zip(det[2:6].tolist(), scales)]
        rect = plt.Rectangle((xmin, ymin), xmax - xmin, ymax - ymin, fill=False,
                             edgecolor=pens[cid], linewidth=3)
        plt.gca().add_patch(rect)
        text = class_names[cid]
        plt.gca().text(xmin, ymin-2, '{:s} {:.3f}'.format(text, score),
                       bbox=dict(facecolor=pens[cid], alpha=0.5),
                       fontsize=12, color='white')
        #print(str(text)+", Score: "+str(score))
    print("total object detected: "+str(count))
    plt.show()

def isImage(filename):
    isImg = filename.endswith('.png') or filename.endswith('.jpg')
    return isImg

def get_det_value_output(img, raw_det_result, thresh):
    res = []

    for det in raw_det_result:
        cid = int(det[0])
        if cid < 0:
            continue
        score = det[1]
        if score < thresh:
            continue
        scales = [img.shape[1], img.shape[0]] * 2
        xmin, ymin, xmax, ymax = [int(p * s) for p, s in zip(det[2:6].tolist(), scales)]
        text = class_names[cid]
        res.append((cid, score, (xmin, ymin, xmax, ymax)))

    res = sorted(res, key=lambda x: -x[1])
    return res

def detect_single(model, img_path, quantize=False, test=False, no_bias=False):
    if(test==False):
        output = model.detect(load_input(img_path, bin=False), quantize=quantize, no_bias=no_bias)
    else:
        output=0

    image = cv2.imread(img_path)
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    display(image, output.asnumpy()[0], thresh=threshold)
    return

def detect_multi(model, quantize=False, no_bias=False):
    class_file = ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '']
    threshold=0.01

    allfiles = os.listdir(input_folder)
    allfiles = sorted(allfiles)
    count=0
    for f in allfiles:
        image_name = os.path.join(input_folder, f)
        print f
        data_folder='/home/prdcv/PycharmProjects/gvh205/Pruning/test'
        if os.path.isfile(image_name) and isImage(image_name):
            output = model.detect(load_input(image_name), quantize=quantize, no_bias=no_bias)
            # output = model.detect(load_input(os.path.join(data_folder,str(count)+'.bin'), bin=True), quantize=quantize, no_bias=no_bias)
            # count=count+1
            image = cv2.imread(image_name)
            det_value = get_det_value_output(image, output.asnumpy()[0], thresh=threshold)
            width=image.shape[1]
            height = image.shape[0]

            for obj in det_value:
                prob=round(obj[1],4)
                left = max(0, obj[2][0])
                top = max(0, obj[2][1])
                right = min(width, obj[2][2])
                bot = min(height, obj[2][3])

                line = f.replace('.jpg', '') + " " + str(prob) + " " + str(left) + " " + str(top) + " " + str(right) + " " + str(bot) + '\n'
                class_file[obj[0]] = class_file[obj[0]] + line

            #image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            #display(image, output.asnumpy()[0], thresh=threshold)
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
    for i in range(20):
        file = open(output_folder + 'comp4_det_test_' + class_names[i] + '.txt', 'w')
        file.write(class_file[i])
        file.close()

mobilenet_SSD_300 = mobilenetSSD.Model(model_file, weight_folder,bias_folder,quantize=False, channel_quantization=True, writefile=write_file)
begin = time.time()
if(mAP_cal==True):
    detect_multi(mobilenet_SSD_300, quantize=False, no_bias=False)
else:
    detect_single(mobilenet_SSD_300,image_file,quantize=False, no_bias=False)
print("processing time: "+str(time.time()-begin))
print('end')

